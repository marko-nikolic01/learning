# T12 2023/2024

Ovaj zadatak se daje za vežbu da bi se stekao utisak koja je gornja granica kompleksnosti do koje može ići prebacivanje `while` petlje u `for` petlju.

Cilj zadatka **nije** da se ubrza, nego da se samo transformiše i paralelizuje.
